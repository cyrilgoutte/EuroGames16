# input:
# X - matrix of size n x p, where n is the number of instances, and p is the number of features
# y - a vector of values of length n - the regressor output
# mu - a matrix, where each column corresponds to a mean parameter of NIG 
# invV - an array of inverse covariance matrices (array indexed by the third dimension)
# a - a vector of shape parameters of InverseGamma
# b - a rate parameter of InverseGamma
posteriorNIG <-
  function(X,y,mu,invV,a,b){

    if (dim(X)[1] != length(y)){
      stop('First dimension of X must be equal to length of y')
    }
    
    # case of the initialization with valid prior - initializes invV by a diagonal matrix 
    if (length(invV) == 1 & invV[1] < Inf){
      invV <- diag(rep(invV),dim(X)[2])
      dim(invV)[3] <- 1 # 1-dim tensor
      mu <- matrix(rep(mu,dim(X)[2]),ncol=1)
    } 
    
    # case of the initialization with uninformative (improper) prior - sets invV to a zero matrix
    if (length(invV) == 1 & invV[1] == Inf){
      invV <- diag(numeric(dim(X)[2]))
      dim(invV)[3] <- 1 # 1-dim tensor
      mu <- matrix(numeric(dim(X)[2]),ncol=1)
    } 

    if (dim(X)[2] != dim(invV)[1]){
      stop('Second dimension of X must be equal to the dimensions of invV')
    }

    if (dim(X)[2] != dim(mu)[1]){
      stop('Second dimension of X must be equal to first dimension of mu')
    }

    if ((dim(mu)[2] != dim(invV)[3]) | (dim(mu)[2] != length(a)) | (dim(mu)[2] != length(b))){
      stop('Number of models to be updated need to be consistent across parameters')
    }

    invVP <- invV + rep(t(X) %*% X,dim(invV)[3])
    aP <- a + dim(X)[1]/2

    muP <- mu # init
    bP <- b # init
    
    # looping over the number of models whose parameters need to be updated
    for (i in 1:dim(mu)[2]) {
      muP[,i] <- solve(invVP[,,i],(invV[,,i] %*% as.matrix(mu[,i])) + (t(X) %*% y))
      
      if (all(invV == 0)){ # uninformative prior (improper) 
        err <- y - X %*% muP
        bP <- 0.5 * t(err) %*% err
      } else {
       bP[i] <- b[i] + 0.5 * (t(mu[,i]) %*% invV[,,i] %*% mu[,i] + t(y) %*% y - t(muP[,i]) %*% invVP[,,i] %*% muP[,i])
      }
    }
    
    return(list(muP,invVP,aP,bP))
  }