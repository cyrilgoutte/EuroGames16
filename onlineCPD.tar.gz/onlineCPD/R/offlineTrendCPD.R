offlineTrendCPD <-
function(data, time = NULL, hazard_func = const_hazard,
                      muP=0, invVP=0.01, aP=0.001, bP=0.001){
  if(!is.matrix(data)) {
    if(is.null(dim(data)[2])) data <- matrix(data,ncol=1)
    else                      data <- as.matrix(data)
  }
  lambda <- 2000
  T      <- dim(data)[1]
  nSeries    <- dim(data)[2]
  
  # we need to have at least 3 data samples to run a (bayesian) linear regression (2 parameters)
  if (T < 4){
    print('Not enough data samples (need at least 4 to start)')
    return(NULL);
  }
  

  ### we will keep separate structure for each posterior corresponding to a different data dimension (time series).
  ### the only place where these posteriors are combined is in the prediction
  
  muT <- list()
  bT <- list()
  for (serIdx in 1:nSeries) {
    paramLst <- posteriorNIG(t(matrix(c(1:3,rep(1,3)),ncol = 3,byrow = TRUE)),matrix(data[1:3,serIdx]),muP,invVP,aP,bP);
    muT[[serIdx]] <- paramLst[[1]]
    invVT <- paramLst[[2]] # the posterior does not depend on the value of y
    aT <- paramLst[[3]] # the posterior does not depend on the value of y
    bT[[serIdx]] <- paramLst[[4]]
  }
  
  R      <- matrix(0,nrow=T+1,ncol=T+1)
  R[1,1] <- R[2,2] <- R[3,3] <- R[4,4] <- 1;
  
  maxes  <- vector(mode="integer",length = T + 1)
  maxes[1:3] <- 1:3
  cps    <- vector(mode="integer",length = T + 1)
  est <- vector(mode="integer",length = T)
  estAvg <- vector(mode="integer",length = T)
  estExp <- vector(mode="integer",length = T)
  
  for(t in 4:T){
    
    # precalculate X' * inv (invVT) * X
    xVxTMP <- numeric(dim(invVT)[3])
    for (i in 1:dim(invVT)[3]){
      xVxTMP[i] <- matrix(c(t,1),ncol = 2) %*% solve(invVT[,,i],matrix(c(t,1),ncol = 1))
    }

    predProbs <- matrix(rep(numeric(dim(invVT)[3]),nSeries),ncol = nSeries)
    
    for (serIdx in 1:nSeries) {
      predProbs[,serIdx] <- studentpdf(data[t,serIdx],c(t,1) %*% muT[[serIdx]],(bT[[serIdx]]/aT)*(1 + xVxTMP),2*aT) #CHECK CORRECTNESS! (matrix * vector stuff)
    }
    
    H <- hazard_func(t-3,lambda)
    
    R[4:t,t] <- R[3:(t-1),t-1] * apply(as.matrix(predProbs),1,prod) * (1 - H)
    R[3,t]         <- sum( R[3:(t-1),t-1] * apply(as.matrix(predProbs),1,prod) * H )
    
    R[,t]   <- R[,t] / sum(R[,t])
    
    for (serIdx in 1:nSeries) {
      # calculate posterior from the last 3 observations only
      params3Lst <- posteriorNIG(t(matrix(c((t-2):t,rep(1,3)),ncol = 3,byrow = TRUE)),
                        as.matrix(data[(t-2):t,serIdx]),muP,invVP,aP,bP);
      paramsAll <- posteriorNIG(matrix(c(t,1),ncol = 2),t(as.matrix(data[t,serIdx])),muT[[serIdx]],invVT,aT,bT[[serIdx]]);

      muT[[serIdx]] <- cbind(params3Lst[[1]],paramsAll[[1]]);
      
      # update invVT and bT last as they are shared accross series
      if (serIdx == nSeries){
        invVT <- abind(params3Lst[[2]],paramsAll[[2]]);
        aT <- append(params3Lst[[3]],paramsAll[[3]]);
      }
      
      bT[[serIdx]] <- append(params3Lst[[4]],paramsAll[[4]]);
    }
    
    maxes[t]  <- match(max(R[,t]),R[,t])
    cps[t]    <- t - maxes[t]
  }
  cps <- sort(unique(cps))

  Rtemp<-R
  for (i in 1:T){
    est[i]<-sum(diag(Rtemp))
    estAvg[i]<-est[i]/length(diag(Rtemp))
    estExp[i] <- sum(diag(Rtemp)*diag(Rtemp))/est[i]
    Rtemp<-Rtemp[1:nrow(Rtemp)-1,2:nrow(Rtemp)]
  }
  
  estExp[is.nan(estExp)] <- 0
  
  result <- list(R=R,data=data,time=time,a=aT,b=bT,v=invVT,mu=muT,max=maxes,changes=cps,postprob=est,postprob2=estAvg, postprob3=estExp)
  class(result) <- "oTrendCPD"
  
  return(result)
  ####SHOULD WE TRUNCATE SMALL VALUES IN R TO SAVE SPACE???
}
