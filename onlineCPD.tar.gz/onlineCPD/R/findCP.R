findCP <- function(oCPD,buffer=10,k=NULL) {
  if(buffer > length(oCPD$max)) stop("buffer must be less than the number of data points")
  
  max <- oCPD$max
  imax <- vector("numeric",length(max))
  for(i in 1:length(max)) imax[i] <- i - max[i]
  changes <- sort(unique(imax))
  
  while(any(diff(changes)<=buffer)){
    changes[c(k1 <- which(diff(changes)<=buffer),k2 <- k1 + 1)]
    for(i in 1:length(k1)){
      tiedpair <- c(k1[i],k2[i])
      tiedrun <- which(imax == changes[tiedpair[1]] | imax == changes[tiedpair[2]])
      v1 <- min(changes[tiedpair[1]],changes[tiedpair[2]])
      v2 <- max(changes[tiedpair[1]],changes[tiedpair[2]])
      difference <- v2 - v1
      minran <- v1 - ceiling(buffer / 2) + ceiling(difference / 2)
      maxran <- v2 + ceiling(buffer / 2) - ceiling(difference / 2)
      tiedrun <- tiedrun[tiedrun > maxran]
      runProbs <- sapply(minran:maxran,
                         function(val) return(sum(diag(oCPD$R[tiedrun-val,tiedrun]))))
      imax[which(imax == changes[tiedpair[1]] | imax == changes[tiedpair[2]])]  <-  minran + which.max(runProbs) - 1 
    }
    changes <- sort(unique(imax))
  }
  
  if (length(changes)>2){
    changes<-changes[2:(length(changes)-1)]
  }else{changes<-vector(mode="numeric", length=0)}
  
  if(!is.null(k)){
    if(length(changes)>k) {
      oCPD$postprob<-oCPD$postprob[2:(length(oCPD$postprob)-1)]
      changes<-changes[order(oCPD$postprob[c(changes)], decreasing=TRUE)[1:k]]
      changes<-sort(changes, decreasing=FALSE)
    }
  }
  
  return(changes)
}