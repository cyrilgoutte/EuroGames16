plot.oTrendCPD <-
  function(x,lines=TRUE,title="",leg.name="Variable",cleanCP=TRUE,buffer=10, ...) {
    plot.oCPD(x,lines,title,leg.name,cleanCP,buffer,...)
  }