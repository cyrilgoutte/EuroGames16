str.oCPD <-
function(object, ...) {
  summary(object,...)  
}
