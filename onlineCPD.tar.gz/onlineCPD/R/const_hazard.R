const_hazard <-
function(r, lambda) {
  return(1/lambda * rep(1,r))
}
